package Character;

import java.awt.image.BufferedImage;

public class Entity {
	//public int health
	public int x,y;
	public int speed;
	public BufferedImage cat,dog;
}
