package final_project;

import javax.swing.JFrame;


public class main {

	public static void main(String[] args) {
		JFrame window  = new JFrame();
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setSize(1200,800);
		window.setResizable(false);
		window.setTitle("Dog cat fight");
        
		//ImageIcon backgroundImage = new ImageIcon("/player/background.png");
		GamePanel gamepenal = new GamePanel();
		window.add(gamepenal);
		
		//window.pack();
		window.setLocationRelativeTo(null);
		window.setVisible(true);
		
		gamepenal.startgameThread();
	}

}
