package final_project;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;


import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;

import Character.Player;
import Character.Player2;
import Health.Health;

public class GamePanel extends JPanel implements Runnable{
	Thread gameThread;
	Timer timer;
	BufferedImage backgroundImage;
	BufferedImage bone;
	KeyHadler Key1 = new KeyHadler();
	KeyHadler Key2 = new KeyHadler();
	Mousehandler mouse = new Mousehandler();
	Player player1= new Player(this,Key1);
	Player2 player2= new Player2(this,Key2);
	Health health1=new Health(this,100);
	

	int FPS=60;
	public GamePanel() {
		this.setPreferredSize(new Dimension(1200,800));
		this.setBackground(Color.white);
		try {
			backgroundImage = ImageIO.read(getClass().getResourceAsStream("/player/background.png"));
			bone = ImageIO.read(getClass().getResourceAsStream("/player/bone.png"));
		}catch(IOException e){
			e.printStackTrace();
		}
	    
		this.addKeyListener(Key1);
		this.addKeyListener(Key2);
		this.addMouseListener(mouse);
		this.setFocusable(true);
		//timer = new Timer(10);
		
	}
	
	public void startgameThread() {
		gameThread = new Thread(this);
		gameThread.start();
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Graphics2D g2 =(Graphics2D)g;
		//g2.drawImage(backgroundImage, 0, 0, null);
		g2.drawImage(backgroundImage, 0,0,1200,800, null);
		g2.drawImage(bone, 600,400,40,40, null);
		player2.draw(g2);
		player1.draw(g2);
		health1.draw(g2);
		g2.dispose();
	}

	

	@Override
	public void run() {
		double interval = 1000000000/FPS; //player更新時間
		 double healthInterval = 1000000000 / 1; // 血條更新間隔，1次/秒

		double nextTime = System.nanoTime()+interval;
		 double nextHealthTime = System.nanoTime() + healthInterval;
		
		while(gameThread != null) {
			double currentTime = System.nanoTime();
			
			update();
			if(currentTime>nextHealthTime) {
				health1.updateHealth(5);
				nextHealthTime += healthInterval;
			}
			repaint();
	
			try {
				double reamainTime = nextTime - System.nanoTime();
				reamainTime = reamainTime/1000000;
				if(reamainTime<0) reamainTime=0;
				
				Thread.sleep((long) reamainTime);
				nextTime += interval;
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}	
	}

	private void update() {
		player2.update();
		player1.update();
		
	}
	
	
}
