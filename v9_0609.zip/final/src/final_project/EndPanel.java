package final_project;

import javax.swing.*;

import Background.Background;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

public class EndPanel extends JPanel {
    private JFrame window;

    public EndPanel(Background bg,JFrame window,BufferedImage winner) {
        this.window = window;
        window.getContentPane().removeAll();
        setLayout(new BorderLayout());

        // JLabel titleLabel = new JLabel();

        // ImageIcon imageIcon = new ImageIcon(bg.background);
        // titleLabel.setIcon(imageIcon);



        JButton RestartButton = new JButton("Restart Game");
        RestartButton.setFont(new Font("Serif", Font.BOLD, 24));
        RestartButton.setForeground(Color.ORANGE);
        RestartButton.setBounds(380, 590, 440, 70); 
        RestartButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showGamePanel();
            }
        });
        JButton ExitButton = new JButton("Exit Game");
        ExitButton.setFont(new Font("Serif", Font.BOLD, 24));
        ExitButton.setForeground(Color.ORANGE);
        ExitButton.setBounds(380, 500, 440, 70); 
        ExitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        window.add(RestartButton);
        window.add(ExitButton);

        // JLayeredPane layeredPane = new JLayeredPane();
        // layeredPane.setPreferredSize(new Dimension(1200, 800));

        // layeredPane.add(RestartButton, JLayeredPane.PALETTE_LAYER);
        // add(layeredPane, BorderLayout.CENTER);
    }

    private void showGamePanel() {
        window.getContentPane().removeAll();
        GamePanel gamePanel = new GamePanel(window);
        window.add(gamePanel);
        window.revalidate();
        window.repaint();
        gamePanel.startgameThread();
    }
}
