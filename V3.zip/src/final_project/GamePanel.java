package final_project;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Timer;

import javax.swing.JPanel;

import Bone.Bone;
import Character.Player;
import Character.Player2;
import Health.Health;

public class GamePanel extends JPanel implements Runnable{
	Thread gameThread;
	KeyHadler Key1 = new KeyHadler();
	KeyHadler Key2 = new KeyHadler();
	MouseHandler mouse1 = new MouseHandler();
	Timer timer = new Timer();
	Player player1= new Player(this,Key1);
	Player2 player2= new Player2(this,Key2);
	boolean collide1 = false;
	Bone bone = new Bone(this,mouse1,player1.x,player1.y);
	Health health1=new Health(this,100);
	

	int FPS=120;
	public GamePanel() {
		this.setBackground(Color.white);
		this.setPreferredSize(new Dimension(1200,800));
		this.addKeyListener(Key1);
		this.addKeyListener(Key2);
		this.addMouseListener(mouse1);
		this.setFocusable(true);
	}
	
	public void startgameThread() {
		gameThread = new Thread(this);
		gameThread.start();
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Graphics2D g2 =(Graphics2D)g;
		player2.draw(g2);
		player1.draw(g2);
		bone.draw(g2);
		
		
		health1.draw(g2);
		g2.dispose();
	}

	

	@Override
	public void run() {
		double interval = 1000000000/FPS; //player更新時間
		 double healthInterval = 1000000000 / 3; // 血條更新間隔，30次/秒

		double nextTime = System.nanoTime()+interval;
		 double nextHealthTime = System.nanoTime() + healthInterval;
		
		while(gameThread != null) {
			double currentTime = System.nanoTime();
		
			if(bone.whos_turn == 1) {
//				if(player2.y>bone.y+bone.height ||bone.y>player2.y+player2.height ||
//						player2.x>bone.x+bone.weight ||bone.x>player2.x+player2.weight) //if後面接FALSE
				if(bone.getBounds().intersects(player2.getBounds())){
					collide1=true;
				}
				else {
					collide1=false;
				}
			}else {
				collide1=false;
			}
			update();
			if(currentTime>nextHealthTime) {
				health1.updateHealth(5);
				nextHealthTime += healthInterval;
			}
			repaint();
	
			try {
				double reamainTime = nextTime - System.nanoTime();
				reamainTime = reamainTime/1000000;
				if(reamainTime<0) reamainTime=0;
				
				Thread.sleep((long) reamainTime);
				nextTime += interval;
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}	
	}

	private void update() {
		player2.update();
		player1.update();
		bone.update(collide1,player1,player2);
		
	}
	
	
}
