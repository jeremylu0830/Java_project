//package final_project;
//
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;

//public class ActionHandler implements ActionListener {

//	@Override
//	public void actionPerformed(ActionEvent e) {
//        x+=xVelocity;
//        yVelocity+=gravity;
//        y+=yVelocity;
//        if(y>=PANEL_HEIGHT) {
//            y=PANEL_HEIGHT; 
//            yVelocity=0; 
//            xVelocity=0; 
//            timer.stop();
//            isThrowing=false; //拋物運動停止
//        }
//        if(x>=PANEL_WIDTH-boneWidth||x<=0){ //當骨頭碰到左右邊界時停止
//            yVelocity=0; 
//            xVelocity=0;
//            timer.stop();
//            isThrowing=false; //拋物運動停止
//        }
//        repaint();
//		
//	}

//}
