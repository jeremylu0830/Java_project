import java.io.*;

public class StreamHelper {
    
    public void output(ArrayList output) {
        try {
        ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("Account.ser"));
        os.writeObject(output);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public ArrayList input() {
        ArrayList list = null;

        try {
        ObjectInputStream is = new ObjectInputStream(new FileInputStream("Account.ser"));
        list = (ArrayList) is.readObject();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        return list;
    }    
}