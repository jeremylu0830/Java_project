import java.util.*;
import java.io.*;

public class ArrayList implements Serializable {
    private Account[] elems;
    private int next;
    private static final long serialVersionUID = -4560544466L;
    
    public ArrayList(int capacity) {
        elems = new Account[capacity];
    }
    
    public ArrayList() {
        this(50);
    }
    
    public void add (Account o) {
        if (next == elems.length) {
            elems = Arrays.copyOf(elems, elems.length*2);
            elems[next++] = o;
        }
        else {
            elems[next++] = o;
        }
    }
    
    public Account get (int i) {
        return elems[i];
    }
    
    public Account[] getElems() {
        return elems;
    }
    
    public int size() {
        return next;
    }
}