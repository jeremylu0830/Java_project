import java.io.*;
import java.lang.*;

public class Account implements Serializable{
    private int totalExpenditureOfDay ;
    private int expenditureOfDinner;
    private int expenditureOfBreakfast;
    private int expenditureOfLunch;
    private int expenditureOfOthers;
    private String date;                            //格式 20XX/XX/XX
    
    public Account(int expenditureOfBreakfast, int expenditureOfLunch, int expenditureOfDinner,
     int ExpenditureOfOthers, String date) {
         this.expenditureOfBreakfast = expenditureOfBreakfast;
         this.expenditureOfLunch = expenditureOfLunch;
         this.expenditureOfDinner = expenditureOfDinner;
         this.expenditureOfOthers = expenditureOfOthers;
         this.date = date;
     }
     
     public int getExpenditureOfDinner() {
         return expenditureOfDinner;
     }

     public int getExpenditureOfBreakfast() {
         return expenditureOfBreakfast;
     }
     public int getExpenditureOfLunch() {
         return expenditureOfLunch;     
     }
     public int getExpenditureOfOthers() {
         return expenditureOfOthers;
     }
     public int getTotalExpenditureOfDay() {
         return totalExpenditureOfDay;
     }
     
     public void calculateTotalExpenditureOfDay () {
         this.totalExpenditureOfDay = (expenditureOfDinner)+(expenditureOfBreakfast)+
         (expenditureOfLunch)+ (expenditureOfOthers);
     }
     
     public String printAccount() {
         String detail = "日期: "+date+" 早餐支出: "+Integer.toString(this.expenditureOfBreakfast)
         +" 午餐支出: "+Integer.toString(this.expenditureOfLunch)+" 晚餐支出: "+Integer.toString(this.expenditureOfDinner)
         +" 其他支出: "+Integer.toString(this.expenditureOfOthers);
         
         return detail;
     }
}