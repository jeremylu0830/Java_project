package Powerup;

public class DoubleThrow {
	
}
