package final_project;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import Background.Background;
import Bone.Bone;
import Character.Player;
import Character.Player2;
import Health.Health;
import History.FileIO;
import Pillar.Pillar;

public class GamePanel extends JPanel implements Runnable {
    Thread gameThread;
    Graphics2D g2;
    Random rand = new Random();
    KeyHandler Key1 = new KeyHandler();
    KeyHandler Key2 = new KeyHandler();
    MouseHandler mouse1 = new MouseHandler();
    Pillar pillar = new Pillar(this);
    Background background = new Background(this);
    Player player1 = new Player(this, Key1);
    Player2 player2 = new Player2(this, Key2);
    int winds = 0,maxHealth = 5;
    JLabel wind_label = new JLabel("<html><span style='font-size:20px'>Winds : " + winds + "</span></html>");
    boolean collide1 = false, collide2 = false, bone_hits_pillar = false, hits_bound = false, collide_or_not;
    Bone bone = new Bone(this, mouse1, Key1, Key2, player1.x, player1.y);
    Health health1 = new Health(this, maxHealth);
    Health health2 = new Health(this, maxHealth);
    JFrame JF;
    BufferedImage winner1;
    BufferedImage winner2;
    private boolean gameRunning = true;

    int FPS = 120;

    public GamePanel(JFrame JF) {
        this.add(wind_label);
        this.setComponentZOrder(wind_label, 0);
        this.setBackground(Color.white);
        this.setPreferredSize(new Dimension(1200, 800));
        this.addKeyListener(Key1);
        this.addKeyListener(Key2);
        this.addMouseListener(mouse1);
        this.setFocusable(true);
        this.JF = JF;
    }

    public void startgameThread() {
        gameThread = new Thread(this);
        gameThread.start();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g2 = (Graphics2D) g;
        background.draw(g2);
        if (gameRunning) {
            wind_label.paint(g2.create(550, 0, 200, 30));
            wind_label.setText("<html><span style='font-size:20px'>Winds : " + (winds) + "</span></html>");
            player2.draw(g2);
            player1.draw(g2);
            bone.draw(g2);
            pillar.draw(g2);
            health1.draw(g2, 10, 10);
            health2.draw(g2, 980, 10);
        } else {
            try {
                winner1 = ImageIO.read(getClass().getResourceAsStream("/player/dogwin.png"));
                winner2 = ImageIO.read(getClass().getResourceAsStream("/player/catwin.png"));
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (health1.currentHealth == 0){
                g2.drawImage(winner1, 230, 50, 800, 800, null);
            }
            else if (health2.currentHealth == 0){
                g2.drawImage(winner2, 180, 50, 800, 800, null);
            }
        }
        g2.dispose();
    }

    @Override
    public void run() {
        double interval = 1000000000 / FPS;
        double nextTime = System.nanoTime() + interval;

        while (gameRunning) {
            if (bone.whos_turn == 1) {
                if (bone.getBounds().intersects(player2.getBounds())) {
                    collide1 = true;
                    winds = rand.nextInt(10) - 5;
                    health2.updateHealth(5);
                } else {
                    collide1 = false;
                }
                collide2 = false;
            } else {
                if (bone.getBounds().intersects(player1.getBounds())) {
                    collide2 = true;
                    winds = rand.nextInt(10) - 5;
                    health1.updateHealth(5);
                } else {
                    collide2 = false;
                }
                collide1 = false;
            }

            if (bone.getBounds().intersects(pillar.getBounds())) {
                bone_hits_pillar = true;
                winds = rand.nextInt(10) - 5;
            } else {
                bone_hits_pillar = false;
            }
            if ((bone.y >= 800 || bone.x >= 1200 || bone.x <= 0)) {
                hits_bound = true;
                winds = rand.nextInt(10) - 5;
            } else {
                hits_bound = false;
            }
            collide_or_not = collide1 || collide2 || bone_hits_pillar || hits_bound;

            update();
            repaint();

            try {
                double remainTime = nextTime - System.nanoTime();
                remainTime = remainTime / 1000000;
                if (remainTime < 0) remainTime = 0;

                Thread.sleep((long) remainTime);
                nextTime += interval;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (health1.currentHealth == 0) setWinner(2);
            else if (health2.currentHealth == 0) setWinner(1);
        }
    }

    private void update() {
        player2.update();
        player1.update();
        bone.update(collide_or_not, player1, player2, winds);
        wind_label.setText("<html><span style='font-size:20px'>Winds : " + (winds) + "</span></html>");
        wind_label.revalidate();
        wind_label.repaint();
    }

    private void setWinner(int winnerNum) {
        gameRunning = false;
        repaint();
        FileIO.writeToFile(winnerNum == 1? "Cat":"Dog");
        EndPanel endPanel = new EndPanel(background,JF,winnerNum == 1? winner2:winner1);
        JF.add(endPanel);
        JF.revalidate();
        JF.repaint();
    }
}
