package final_project;

import javax.swing.*;

import Background.Background;
import History.FileIO;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class EndPanel extends JPanel {
    private Background background;
    private BufferedImage winner;
    private JFrame window;

    public EndPanel(Background bg,JFrame window,BufferedImage winner) {
        this.window = window;
        this.background = bg;
        this.winner = winner;
        window.getContentPane().removeAll();
        setLayout(new BorderLayout());

        JButton HistoryButton = new JButton("History");
        HistoryButton.setFont(new Font("Serif", Font.BOLD, 24));
        HistoryButton.setForeground(Color.ORANGE);
        HistoryButton.setBounds(380, 410, 440, 70); 
        HistoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                window.getContentPane().removeAll();
                ArrayList<String> file = FileIO.readfile();
                displayHistory(file);
            }
        });

        JButton RestartButton = new JButton("Play Again");
        RestartButton.setFont(new Font("Serif", Font.BOLD, 24));
        RestartButton.setForeground(Color.ORANGE);
        RestartButton.setBounds(380, 500, 440, 70); 
        RestartButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showGamePanel();
            }
        });
        JButton ExitButton = new JButton("Exit Game");
        ExitButton.setFont(new Font("Serif", Font.BOLD, 24));
        ExitButton.setForeground(Color.ORANGE);
        ExitButton.setBounds(380, 590, 440, 70); 
        ExitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        window.add(HistoryButton);
        window.add(RestartButton);
        window.add(ExitButton);
    }

    private void showGamePanel() {
        window.getContentPane().removeAll();
        GamePanel gamePanel = new GamePanel(window);
        window.add(gamePanel);
        window.revalidate();
        window.repaint();
        gamePanel.startgameThread();
    }

    private void displayHistory(ArrayList<String> fileContent) {
        window.getContentPane().removeAll();

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);

        for (String line : fileContent) {
            textArea.append(line + "\n");
        }

        JScrollPane scrollPane = new JScrollPane(textArea);
        window.add(scrollPane, BorderLayout.CENTER);

        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Serif", Font.BOLD, 24));
        backButton.setForeground(Color.ORANGE);
        backButton.setBounds(380, 680, 440, 70); 
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                EndPanel end = new EndPanel(background, window, winner);
                window.add(end);
                window.revalidate();
                window.repaint();
            }
        });
        window.add(backButton, BorderLayout.SOUTH);
        window.revalidate();
        window.repaint();
    }
}
