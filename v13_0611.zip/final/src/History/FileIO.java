package History;

import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

public class FileIO {
    // 讀取檔案的方法
    public static ArrayList<String> readfile() {
        ArrayList<String> fileContent = new ArrayList<String>();

        // Try-with-resources statement to ensure BufferedReader is closed properly
        try (BufferedReader br = new BufferedReader(new FileReader("src/History/History.txt"))) {
            String currentLine;
            while ((currentLine = br.readLine()) != null) {
                fileContent.add(currentLine);
            }
        } catch (IOException e) {
			fileContent.add("No any record yet");
        }

        return fileContent;
    }

    // 寫入檔案的方法
    public static void writeToFile(String win) {
        File file = new File("src/History/History.txt");
        String Winner;
        // 如果檔案不存在，先建立檔案
        if (!file.exists()) {
            try {
                file.createNewFile(); // 建立檔案
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        ArrayList <String> content = readfile();
        while (content.size() > 10) {
            content.remove(0);
        }
        Date date = new Date();
        System.out.println("contentSize = " + content.size());
        Winner = "Round" + (content.size()+1) + ": " + win + " is the winner (" + date + ")";
        content.add(Winner);
        System.out.println("content size = " + content.size());
        // 使用 try-with-resources 來自動關閉 BufferedWriter
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file))) {
            for (String line : content) {
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
