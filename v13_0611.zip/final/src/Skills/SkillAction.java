package Skills;

public interface SkillAction {
    void execute();
}

