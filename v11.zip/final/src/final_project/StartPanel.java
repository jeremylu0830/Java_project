package final_project;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class StartPanel extends JPanel {
    private JFrame window;

    public StartPanel(JFrame window) {
        this.window = window;
        setLayout(new BorderLayout());
        
        JLabel titleLabel = new JLabel();
        ImageIcon imageIcon = null;
        try {
            BufferedImage img = ImageIO.read(getClass().getResource("/player/start.jpg"));
            if (img != null) {
                Image scaledImage = img.getScaledInstance(1200, 800, Image.SCALE_SMOOTH);
                imageIcon = new ImageIcon(scaledImage);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        if (imageIcon != null) {
            titleLabel.setIcon(imageIcon);
        } else {
            titleLabel.setText("Start Game");
            titleLabel.setFont(new Font("Serif", Font.BOLD, 48));
            titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        }


        JButton startButton = new JButton("Start Game");
        startButton.setFont(new Font("Serif", Font.BOLD, 24));
        startButton.setForeground(Color.ORANGE);
        startButton.setBounds(380, 590, 440, 70); 
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showGamePanel();
            }
        });

        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setPreferredSize(new Dimension(1200, 800));
        
        titleLabel.setBounds(0, 0, 1200, 800);
        layeredPane.add(titleLabel, JLayeredPane.DEFAULT_LAYER);
        layeredPane.add(startButton, JLayeredPane.PALETTE_LAYER);
        add(layeredPane, BorderLayout.CENTER);
    }

    private void showGamePanel() {
        window.getContentPane().removeAll();
        GamePanel gamePanel = new GamePanel(window);
        window.add(gamePanel);
        window.revalidate();
        window.repaint();
        gamePanel.startgameThread();
    }
}
