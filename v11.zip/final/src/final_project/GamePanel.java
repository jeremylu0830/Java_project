package final_project;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import Background.Background;
import Bone.Bone;
import Character.Player;
import Character.Player2;
import Health.Health;
import History.FileIO;
import Pillar.Pillar;
import Skills.Skill;
import Skills.SkillAction;

public class GamePanel extends JPanel implements Runnable {
    Thread gameThread;
    Graphics2D g2;
    Random rand = new Random();
    KeyHandler Key1 = new KeyHandler();
    KeyHandler Key2 = new KeyHandler();
    MouseHandler mouse1 = new MouseHandler();
    Pillar pillar = new Pillar(this);
    Background background = new Background(this);
    Player player1 = new Player(this, Key1);
    Player2 player2 = new Player2(this, Key2);
    int winds = 0, maxHealth = 20;
    JLabel wind_label = new JLabel("<html><span style='font-size:20px'>Winds : " + winds + "</span></html>");
    boolean collide1 = false, collide2 = false, bone_hits_pillar = false, hits_bound = false, collide_or_not;
    Bone bone;
    Bone extraBone = null;
    Health health1 = new Health(this, maxHealth);
    Health health2 = new Health(this, maxHealth);
    JFrame JF;
    BufferedImage winner1;
    BufferedImage winner2;
    private boolean gameRunning = true;
    private boolean boneGrown = false;
    private boolean buttonPressed = false;

    int FPS = 120;

    Skill growBoneSkill;
    Skill doubleBoneSkill;
    Skill increaseDamageSkill;
    Skill healSkill;

    public GamePanel(JFrame JF) {
        // 使用绝对布局
        this.setLayout(null);
        this.setBackground(Color.white);
        this.setPreferredSize(new Dimension(1200, 800));
        this.addKeyListener(Key1);
        this.addKeyListener(Key2);
        this.addMouseListener(mouse1);
        this.setFocusable(true);
        this.JF = JF;

        // 设置标签的位置和大小
        wind_label.setBounds(550, 0, 200, 30);
        this.add(wind_label);

        // 初始化技能
        initializeSkills();

        // 添加技能按钮
        addSkillButtons();

        // 初始化骨头
        bone = new Bone(this, mouse1, Key1, Key2, player1.x, player1.y,1);
    }

    private void initializeSkills() {
        growBoneSkill = new Skill("Grow Bone", new SkillAction() {
            @Override
            public void execute() {
                if (!buttonPressed) {
                    bone.doubleSize();
                    if (extraBone != null) {
                        extraBone.doubleSize();
                    }
                    boneGrown = true;
                    buttonPressed = true;
                }
            }
        });

        doubleBoneSkill = new Skill("Double Bone", new SkillAction() {
            @Override
            public void execute() {
                if (!buttonPressed) {
                    if (extraBone == null) {
                        if (bone.whos_turn == 1) {
                            extraBone = new Bone(GamePanel.this, mouse1, Key1, Key2, player1.x, player1.y - 100,1);
                        } else {
                            extraBone = new Bone(GamePanel.this, mouse1, Key1, Key2, player2.x, player2.y - 100,2);
                        }
                    }
                    buttonPressed = true;
                }
            }
        });


        increaseDamageSkill = new Skill("Increase Damage", new SkillAction() {
            @Override
            public void execute() {
                if (!buttonPressed) {
                    bone.increaseDamage(5); // Increase damage by 5 (or any other value)
                    buttonPressed = true;
                }
            }
        });

        healSkill = new Skill("Heal", new SkillAction() {
            @Override
            public void execute() {
                if (!buttonPressed) {
                    if (bone.whos_turn == 1) {
                        health1.increaseHealth(20); // 增加玩家1的生命值
                    } else {
                        health2.increaseHealth(20); // 增加玩家2的生命值
                    }
                    buttonPressed = true;
                }
            }
        });
    }

    private void addSkillButtons() {
        growBoneSkill.getButton().setBounds(1100, 50, 100, 30);
        this.add(growBoneSkill.getButton());

        doubleBoneSkill.getButton().setBounds(1100, 100, 100, 30);
        this.add(doubleBoneSkill.getButton());

        increaseDamageSkill.getButton().setBounds(1100, 150, 100, 30);
        this.add(increaseDamageSkill.getButton());

        healSkill.getButton().setBounds(1100, 200, 100, 30);
        this.add(healSkill.getButton());
    }

    public void startgameThread() {
        gameThread = new Thread(this);
        gameThread.start();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g2 = (Graphics2D) g;
        background.draw(g2);
        if (gameRunning) {
            player2.draw(g2);
            player1.draw(g2);
            bone.draw(g2);
            if (extraBone != null) {
                extraBone.draw(g2);
            }
            pillar.draw(g2);
            health1.draw(g2, 10, 10);
            health2.draw(g2, 980, 10);
        } else {
            try {
                winner1 = ImageIO.read(getClass().getResourceAsStream("/player/dogwin.png"));
                winner2 = ImageIO.read(getClass().getResourceAsStream("/player/catwin.png"));
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (health1.currentHealth == 0) {
                g2.drawImage(winner1, 230, 50, 800, 800, null);
            } else if (health2.currentHealth == 0) {
                g2.drawImage(winner2, 180, 50, 800, 800, null);
            }
        }
    }

    @Override
    public void run() {
        double interval = 1000000000 / FPS;
        double nextTime = System.nanoTime() + interval;

        while (gameRunning) {
            if (bone.whos_turn == 1) {
                if (bone.getBounds().intersects(player2.getBounds())) {
                    collide1 = true;
                    winds = rand.nextInt(10) - 5;
                    health2.updateHealth(bone.damage);
                } else {
                    collide1 = false;
                }
                collide2 = false;
            } else {
                if (bone.getBounds().intersects(player1.getBounds())) {
                    collide2 = true;
                    winds = rand.nextInt(10) - 5;
                    health1.updateHealth(bone.damage);
                } else {
                    collide2 = false;
                }
                collide1 = false;
            }

            if (bone.getBounds().intersects(pillar.getBounds())) {
                bone_hits_pillar = true;
                winds = rand.nextInt(10) - 5;
            } else {
                bone_hits_pillar = false;
            }
            if ((bone.y >= 800 || bone.x >= 1200 || bone.x <= 0)) {
                hits_bound = true;
                winds = rand.nextInt(10) - 5;
            } else {
                hits_bound = false;
            }
            collide_or_not = collide1 || collide2 || bone_hits_pillar || hits_bound;

            if (extraBone != null) {
                if (extraBone.whos_turn == 1) {
                    if (extraBone.getBounds().intersects(player2.getBounds())) {
                        collide1 = true;
                        winds = rand.nextInt(10) - 5;
                        health2.updateHealth(bone.damage);
                    } else {
                        collide1 = false;
                    }
                    collide2 = false;
                } else {
                    if (extraBone.getBounds().intersects(player1.getBounds())) {
                        collide2 = true;
                        winds = rand.nextInt(10) - 5;
                        health1.updateHealth(bone.damage);
                    } else {
                        collide2 = false;
                    }
                    collide1 = false;
                }

                if (extraBone.getBounds().intersects(pillar.getBounds())) {
                    bone_hits_pillar = true;
                    winds = rand.nextInt(10) - 5;
                } else {
                    bone_hits_pillar = false;
                }
                if ((extraBone.y >= 800 || extraBone.x >= 1200 || extraBone.x <= 0)) {
                    hits_bound = true;
                    winds = rand.nextInt(10) - 5;
                } else {
                    hits_bound = false;
                }
                collide_or_not = collide1 || collide2 || bone_hits_pillar || hits_bound;
            }

            update();
            repaint();

            try {
                double remainTime = nextTime - System.nanoTime();
                remainTime = remainTime / 1000000;
                if (remainTime < 0) remainTime = 0;

                Thread.sleep((long) remainTime);
                nextTime += interval;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (health1.currentHealth == 0) setWinner(2);
            else if (health2.currentHealth == 0) setWinner(1);
        }
    }

    private void update() {
        player2.update();
        player1.update();
        bone.update(collide_or_not, player1, player2, winds);
        if (extraBone != null) {
            extraBone.update(collide_or_not, player1, player2, winds);
        }
        wind_label.setText("<html><span style='font-size:20px'>Winds : " + (winds) + "</span></html>");
        wind_label.revalidate();
        wind_label.repaint();

        // Reset skills and bone properties at the end of the turn
        if (collide_or_not) {
            if (boneGrown) {
                bone.resetSize();
                if (extraBone != null) {
                    extraBone.resetSize();
                }
                boneGrown = false;
                //growBoneSkill.resetButton();
            }

            if (extraBone != null) {
                extraBone = null;
                //doubleBoneSkill.resetButton();
            }

            bone.resetDamage();

            buttonPressed = false;
        }
    }

    private void setWinner(int winnerNum) {
        gameRunning = false;
        repaint();
        FileIO.writeToFile(winnerNum == 1 ? "Cat" : "Dog");
        EndPanel endPanel = new EndPanel(background, JF, winnerNum == 1 ? winner2 : winner1);
        JF.add(endPanel);
        JF.revalidate();
        JF.repaint();
    }
}