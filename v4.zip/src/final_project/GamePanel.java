package final_project;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Random;
import java.util.Timer;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import Bone.Bone;
import Character.Player;
import Character.Player2;
import Health.Health;
import Pillar.Pillar;

public class GamePanel extends JPanel implements Runnable{
	Thread gameThread;
	Random rand = new Random();
	//JButton button = new JButton("Button");
	KeyHadler Key1 = new KeyHadler();
	KeyHadler Key2 = new KeyHadler();
	MouseHandler mouse1 = new MouseHandler();
	Pillar pillar = new Pillar(this);
	Player player1= new Player(this,Key1);
	Player2 player2= new Player2(this,Key2);
	int winds=0;
	JLabel wind_label = new JLabel("<html><span style='font-size:20px'>Winds : " + winds + "</span></html>"); 
	boolean collide1 = false,collide2 = false,bone_hits_pillar=false,hits_bound=false,collide_or_not;
	Bone bone = new Bone(this,mouse1,player1.x,player1.y);
	Health health1=new Health(this,100);
	

	int FPS=120;
	public GamePanel() {
        this.add(wind_label);
		System.out.println("Adding wind_label");
		System.out.println("Label bounds: " + wind_label.getBounds());
		this.setComponentZOrder(wind_label, 0);
		this.setBackground(Color.white);
		this.setPreferredSize(new Dimension(1200,800));
		this.addKeyListener(Key1);
		this.addKeyListener(Key2);
		this.addMouseListener(mouse1);
		this.setFocusable(true);
	}
	
	public void startgameThread() {
		gameThread = new Thread(this);
		gameThread.start();
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 =(Graphics2D)g;
		wind_label.paint(g2.create(550, 0, 200, 30));
		wind_label.setText("<html><span style='font-size:20px'>Winds : " + (winds) + "</span></html>");
		player2.draw(g2);
		player1.draw(g2);
		bone.draw(g2);
		pillar.draw(g2);
		
		health1.draw(g2);
		g2.dispose();
	}

	

	@Override
	public void run() {
		double interval = 1000000000/FPS; //player更新時間
		double nextTime = System.nanoTime()+interval;

		while(gameThread != null) {
			if(bone.whos_turn == 1) {
//				if(player2.y>bone.y+bone.height ||bone.y>player2.y+player2.height ||
//						player2.x>bone.x+bone.weight ||bone.x>player2.x+player2.weight) //if後面接FALSE
				if(bone.getBounds().intersects(player2.getBounds())){
					collide1=true;
					winds = rand.nextInt(20)-10;
				}
				else {
					collide1=false;
				}
				collide2=false;
			}else {
				if(bone.getBounds().intersects(player1.getBounds())){
					collide2=true;
					winds = rand.nextInt(20)-10;
					health1.updateHealth(5);
				}
				else {
					collide2=false;
				}	
				collide1=false;
			}//骨頭換誰丟
			
			if(bone.getBounds().intersects(pillar.getBounds())) {
				bone_hits_pillar=true;
				winds = rand.nextInt(20)-10;
			}else {
				bone_hits_pillar=false;
			}
			if((bone.y >= 800 || bone.x >= 1200 || bone.x <= 0 )) {
				hits_bound=true;
				winds = rand.nextInt(20)-10;
			}else {
				hits_bound=false;
			}
			collide_or_not = collide1 || collide2 || bone_hits_pillar ||hits_bound;
			update();

			repaint();
	
			try {
				double reamainTime = nextTime - System.nanoTime();
				reamainTime = reamainTime/1000000;
				if(reamainTime<0) reamainTime=0;
				
				Thread.sleep((long) reamainTime);
				nextTime += interval;
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}	
	}

	private void update() {
		player2.update();
		player1.update();
		bone.update(collide_or_not,player1,player2,winds);	        
		wind_label.setText("<html><span style='font-size:20px'>Winds : " + winds + "</span></html>");
        wind_label.revalidate();
        wind_label.repaint();
	}
}
