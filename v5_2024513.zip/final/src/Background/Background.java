package Background;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import final_project.GamePanel;

public class Background extends Rectangle {
	GamePanel gp;
	BufferedImage background;
	int x,y,weight=100,height=400;
	public Background(GamePanel gp) {
		this.gp=gp;
		x=0;
		y=0;
		getBackgroundImage();
	}
    public Rectangle getBounds() {
        return new Rectangle(x, y, weight, height);
    }
	private void getBackgroundImage() {
		try {
			background = ImageIO.read(getClass().getResourceAsStream("/player/background.png"));
		}catch(IOException e){
			e.printStackTrace();
		}
		
	}
	public void draw(Graphics2D g2) {
		BufferedImage image = background;
		g2.drawImage(image, x, y, 1200, 800, null);
	}
}
