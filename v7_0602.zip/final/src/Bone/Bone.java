package Bone;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import Character.Player;
import Character.Player2;
import final_project.GamePanel;
import final_project.KeyHadler;
import final_project.MouseHandler;

public class Bone extends Rectangle {
	GamePanel gp;
	MouseHandler mouse1;
	BufferedImage bone;
	KeyHadler key1;
	KeyHadler key2;
	public int whos_turn = 1;
	public int x,y;
	public int weight=100,height=100;
	double angle=Math.PI/4;
	final double gravity=0.2; 
	boolean isThrowing;
    double xVelocity;
    double yVelocity;
    boolean clicked_once=false;
	int speed;
	
	public Bone(GamePanel gp,MouseHandler mouse1,KeyHadler key1,KeyHadler key2,int x ,int y) {	
		this.gp=gp;
		this.mouse1=mouse1;
		this.key1 = key1;
		this.key2 = key2;
		this.speed = 3;
		setValue(x,y);
		getBoneImage();
	}
	public void setValue(int x,int y) {
		this.x=x+50;
		this.y=y-50;
	}
    public Rectangle getBounds() {
        return new Rectangle(x, y, weight, height);
    }
    
	public void getBoneImage() {
		try {
			bone = ImageIO.read(getClass().getResourceAsStream("/player/bone (1).png"));
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	public void update(boolean collide,Player p1,Player2 p2,int wind) {
        if (mouse1.mouse_clicked && !clicked_once) {
            isThrowing = true;
        } else if (isThrowing) {
            double initialVelocity = (mouse1.mouseReleasedTime - mouse1.mousePressedTime) / 70.0;
            xVelocity =  (1.0+(double)wind/10.0) *initialVelocity * Math.cos(angle);
            yVelocity = -(1.0+(double)wind/10.0)*initialVelocity * Math.sin(angle);

            System.out.println("Time "+initialVelocity);	
            clicked_once=true;
            if(whos_turn==2) xVelocity=-xVelocity;
            isThrowing = false; // only calculate initial velocity once
            
        }
		if(whos_turn == 2){
			if(key2.Up_pressed || key2.Down_pressed || key2.Right_pressed || key2.Left_pressed){
				y = p2.y-50;
				x = p2.x-50;
			}
				
			// if(key2.Up_pressed==true) {
			// 	y=y-speed;
			// }else if(key2.Down_pressed==true) {
			// 	y=y+speed;
			// }else if(key2.Right_pressed==true) {
			// 	x=x+speed;
			// }else if(key2.Left_pressed==true) {
			// 	x=x-speed;
			// }	
		}
		else if(whos_turn == 1){
			if(key1.W_pressed || key1.S_pressed || key1.D_pressed || key1.A_pressed){
				y = p1.y-50;
				x = p1.x+50;
			}
			// if(key1.W_pressed==true) {
			// 	y=y-speed;
			// }else if(key1.S_pressed==true) {
			// 	y=y+speed;
			// }else if(key1.D_pressed==true) {
			// 	x=x+speed;
			// }else if(key1.A_pressed==true) {
			// 	x=x-speed;
			// }
		}
        if(collide) {
        	//System.out.println(x+","+y);
        	
        	if(whos_turn==1)whos_turn=2;
			else whos_turn=1;
			if(whos_turn==1) {
				x = p1.x+50;
				y = p1.y-50;
			}else {
				x = p2.x-50;
				y = p2.y-50;
			}
        	
        	// System.out.println("collide , now , player"+whos_turn);		
        	yVelocity = 0;
            xVelocity = 0;
            clicked_once=false;
        }
		
        if (!isThrowing && (xVelocity != 0 || yVelocity != 0)) {
            x += xVelocity;
            yVelocity += gravity;
            y += yVelocity;        
        }
	}


	public void draw(Graphics2D g2) {
		BufferedImage image = bone;
		g2.drawImage(image, x, y, 100, 100, null);
	}
}