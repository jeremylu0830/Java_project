package Character;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;

public class Entity extends Rectangle {
	//public int health
	public int x;
	public int y;
	public int number;
	//public int width, height;
	public int speed;
	public BufferedImage cat,dog;
}
